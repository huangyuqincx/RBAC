package com.security.springmvc.interceptor;

import com.security.springmvc.model.UserDto;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@Component
public class SimpleAuthenticationInterceptor implements HandlerInterceptor {

    //在preHandle方法中校验用户请求的url是否在用户的权限范围内
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //从当前session中取出当前登录用户身份信息
        Object object = request.getSession().getAttribute(UserDto.SESSION_USER_KEY);
        if(object == null){
            //没有认证通过,提示用户登录
            writeContent(response,"请登录");
        }
        //已经认证通过，根据请求的url, 校验用户是否拥有操作权限
        UserDto userDto = (UserDto) object;
        String requestURI = request.getRequestURI();
        //将权限和url绑定（基于Url的权限管理，一会小组成员会讲到基于角色的权限管理，做简单对比）
        //如果用户的权限中包含了p1权限并且正在访问/r/r1页面，那么可以放行。
        if( userDto.getAuthorities().contains("p1") && requestURI.contains("/r/r1")){
            return true;
        }
        if( userDto.getAuthorities().contains("p2") && requestURI.contains("/r/r2")){
            return true;
        }
        //否则不予以放行，提示用户没有权限，拒绝访问。
        writeContent(response,"没有权限，拒绝访问");
        return false;
    }

    //将响应信息以文本类型返回给客户端
    private void writeContent(HttpServletResponse response, String msg) throws IOException {
        //设置响应编码
        response.setContentType("text/html;charset=utf-8");
        PrintWriter writer = response.getWriter();
        writer.print(msg);
        writer.close();
    }

}
