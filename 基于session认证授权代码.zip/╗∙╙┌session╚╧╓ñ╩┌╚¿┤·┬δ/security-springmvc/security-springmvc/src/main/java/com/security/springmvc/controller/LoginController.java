package com.security.springmvc.controller;

import com.security.springmvc.model.AuthenticationRequest;
import com.security.springmvc.model.UserDto;
import com.security.springmvc.service.AuthenticationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;


@RestController
public class LoginController {

    @Autowired
    AuthenticationService authenticationService;

    //对/login请求进行处理，调用AuthenticationService完成认证
    @RequestMapping(value = "/login",produces = "text/plain;charset=utf-8")
    public String login(AuthenticationRequest authenticationRequest, HttpSession session){
        UserDto userDto = authenticationService.authentication(authenticationRequest);
        //认证通过后，使用HttpSession中的setAttribute方法将用户信息存入session会话中。
        session.setAttribute(UserDto.SESSION_USER_KEY,userDto);
        //认证通过，显示用户名+"登录成功"
        return userDto.getUsername() +"登录成功";
    }

    //增加用户登出方法，在用户登出后将session置为失效
    @GetMapping(value = "/logout",produces = {"text/plain;charset=UTF-8"})
    public String logout(HttpSession session){
        session.invalidate();
        return "退出成功";
    }

    //创建资源/r/r1，实现当资源切换过后，依然可以直接访问，不用再次登录。（会话）
    @GetMapping(value = "/r/r1",produces = {"text/plain;charset=UTF-8"})
    public String r1(HttpSession session){
        String fullname = null;
        //使用getAttribute方法从当前session中根据key取出当前登录用户
        Object object = session.getAttribute(UserDto.SESSION_USER_KEY);
        //返回提示信息给前台
        if(object == null){
            //session中不存在用户信息，说明是匿名人在访问资源
            fullname = "匿名";
        }else{
            //session中存在用户信息，返回该用户的全名
            UserDto userDto = (UserDto) object;
            fullname = userDto.getFullname();
        }
        return fullname+"访问资源r1";
    }

    //增加一个资源/r/r2
    @GetMapping(value = "/r/r2",produces = {"text/plain;charset=UTF-8"})
    public String r2(HttpSession session){
        String fullname = null;
        Object userObj = session.getAttribute(UserDto.SESSION_USER_KEY);
        if(userObj != null){
            fullname = ((UserDto)userObj).getFullname();
        }else{
            fullname = "匿名";
        }
        return fullname + " 访问资源r2";
    }

}
