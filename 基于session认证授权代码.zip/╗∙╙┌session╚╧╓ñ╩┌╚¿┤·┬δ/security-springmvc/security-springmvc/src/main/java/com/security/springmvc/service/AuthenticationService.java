package com.security.springmvc.service;

import com.security.springmvc.model.AuthenticationRequest;
import com.security.springmvc.model.UserDto;


//定义认证接口，通过用户名、密码进行校验
public interface AuthenticationService {
    /**
     * 用户认证
     * @param authenticationRequest 用户认证请求，用户名和密码
     * @return 认证成功的用户信息
     */
    UserDto authentication(AuthenticationRequest authenticationRequest);
}
