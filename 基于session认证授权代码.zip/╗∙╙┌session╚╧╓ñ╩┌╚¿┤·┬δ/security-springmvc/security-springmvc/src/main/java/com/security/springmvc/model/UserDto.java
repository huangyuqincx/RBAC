package com.security.springmvc.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Set;


@Data
@AllArgsConstructor
public class UserDto {

    //定义一个SESSION_USER_KEY，作为Session中存放登录用户信息的key
    public static final String SESSION_USER_KEY = "_user";

    //用户身份信息
    private String id;
    private String username;
    private String password;
    private String fullname;
    private String mobile;

    //定义set类型的用户权限，可以存多个用户权限
    private Set<String> authorities;
}
