package com.security.springmvc.service;

import com.security.springmvc.model.AuthenticationRequest;
import com.security.springmvc.model.UserDto;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Service
public class AuthenticationServiceImpl implements  AuthenticationService{

    /**
     * 用户认证实现类，校验用户身份信息是否合法
     *
     * @param authenticationRequest 用户认证请求，账号和密码
     * @return 认证成功的用户信息
     */
    @Override
    public UserDto authentication(AuthenticationRequest authenticationRequest) {
        //校验参数是否为空（用户名或密码任意一个参数为空）
        if(authenticationRequest == null
            || StringUtils.isEmpty(authenticationRequest.getUsername())
            || StringUtils.isEmpty(authenticationRequest.getPassword())){
            throw new RuntimeException("账号和密码为空");
        }
        //如果两个参数都不为空，根据用户名去查询数据库是否存在此人
        UserDto user = getUserDto(authenticationRequest.getUsername());
        if(user == null){
            throw new RuntimeException("查询不到该用户");
        }
        //如果存在此人，则校验密码是否正确（传来的密码！=数据库中该用户的密码）
        if(!authenticationRequest.getPassword().equals(user.getPassword())){
            throw new RuntimeException("账号或密码错误");
        }
        //用户名密码都正确
        return user;
    }

    //根据用户名在数据库中查询用户信息
    private UserDto getUserDto(String userName){
        return userMap.get(userName);
    }

    //模拟数据库
    private Map<String,UserDto> userMap = new HashMap<>();
    {
        //为张三赋予p1权限，为李四赋予p2权限
        Set<String> authorities1 = new HashSet<>();
        authorities1.add("p1");
        Set<String> authorities2 = new HashSet<>();
        authorities2.add("p2");
        userMap.put("zhangsan",new UserDto("1010","zhangsan","123","张三","133443",authorities1));
        userMap.put("lisi",new UserDto("1011","lisi","456","李四","144553",authorities2));
    }
}
